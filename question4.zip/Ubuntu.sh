#!/bin/sh
#Ubuntu, PackageManager:apt
apt update
apt upgrade
apt install vi -y
