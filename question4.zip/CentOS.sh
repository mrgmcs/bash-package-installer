#!/bash/sh
#CentOS, PackageManager: yum
yum update
yum install vim-enhanced -y 
